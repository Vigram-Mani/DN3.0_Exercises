/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.e.commerce;

import java.util.Scanner;

/**
 *
 * @author vigra
 */
public class ECommerce {

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Shirt", "Apparel"),
            new Product("4", "Shoes", "Footwear"),
            new Product("5", "Book", "Stationery")
        };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter search term: ");
        String searchTerm = scanner.nextLine();
        Product linearSearchResult = LinearSearch.linearSearch(products, searchTerm);
        if (linearSearchResult != null) {
            System.out.println("Linear Search - Product Found: " + linearSearchResult.getProductName());
        } else {
            System.out.println("Linear Search - Product Not Found");
        }
        Product binarySearchResult = BinarySearch.binarySearch(products, searchTerm);
        if (binarySearchResult != null) {
            System.out.println("Binary Search - Product Found: " + binarySearchResult.getProductName());
        } else {
            System.out.println("Binary Search - Product Not Found");
        }

    }
}
