/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.financialforecasting;

/**
 *
 * @author vigra
 */
public class FinancialForecasting {

    public static double calculateFutureValue(double currentValue, double growthRate, int periods) {
       
        if (periods == 0) {
            return currentValue;
        }
        
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double initialInvestment = 1000.0; 
        double annualGrowthRate = 0.05;    
        int years = 10;                    

        double futureValue = calculateFutureValue(initialInvestment, annualGrowthRate, years);
        System.out.printf("The future value of the investment is: %.2f%n", futureValue);
    }
}
