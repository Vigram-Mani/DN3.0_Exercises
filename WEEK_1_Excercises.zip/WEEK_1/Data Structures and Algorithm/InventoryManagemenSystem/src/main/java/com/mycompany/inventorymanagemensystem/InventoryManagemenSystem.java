/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inventorymanagemensystem;

/**
 *
 * @author vigra
 */
public class InventoryManagemenSystem {

    public static void main(String[] args) {
        InventoryManager inventoryManager = new InventoryManager();
        Product product1 = new Product("1", "Laptop", 10, 500);
        Product product2 = new Product("2", "Smartphone", 20, 300);
        inventoryManager.addProduct(product1);
        inventoryManager.addProduct(product2);
        System.out.println("Inventory after adding products:");
        inventoryManager.printInventory();
        Product updatedProduct = new Product("1", "Gaming Laptop", 5, 1000);
        inventoryManager.updateProduct("1", updatedProduct);
        System.out.println("\nInventory after updating product:");
        inventoryManager.printInventory();
        inventoryManager.deleteProduct("2");
        System.out.println("\nInventory after deleting product:");
        inventoryManager.printInventory();
    }
}
