/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sortingcustomerorder;

/**
 *
 * @author vigra
 */
import java.util.Arrays;
public class SortingCustomerOrder {

    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Vigram", 250.00),
            new Order("2", "Siva", 150.00),
            new Order("3", "Yogesh", 500.00),
            new Order("4", "Sethu", 100.00),
            new Order("5", "Sri", 300.00)
        };

        // Bubble Sort
        System.out.println("Orders sorted by Bubble Sort:");
        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        BubbleSort.bubbleSort(bubbleSortedOrders);
        for (Order order : bubbleSortedOrders) {
            System.out.println(order.getOrderId() + ": " + order.getCustomerName() + " - $" + order.getTotalPrice());
        }

        System.out.println();

        // Quick Sort
        System.out.println("Orders sorted by Quick Sort:");
        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        for (Order order : quickSortedOrders) {
            System.out.println(order.getOrderId() + ": " + order.getCustomerName() + " - $" + order.getTotalPrice());
        }
    }
}
