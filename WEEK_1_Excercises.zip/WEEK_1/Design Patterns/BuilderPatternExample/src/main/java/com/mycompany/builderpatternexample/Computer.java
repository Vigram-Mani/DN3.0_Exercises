/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.builderpatternexample;

/**
 *
 * @author vigra
 */
public class Computer {
    private String cpu;
    private int ram;
    private int storage;
    
    private Computer(Builder builder){
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
    }
    
    public static class Builder{
        private String cpu;
        private int ram;
        private int storage;
        
        public Builder cpuSetter(String cpu){
            this.cpu = cpu;
            return this;
        }
        public Builder ramSetter(int ram){
            this.ram = ram;
            return this;
        }
        public Builder storageSetter(int storage){
            this.storage = storage;
            return this;
        }
        public Computer build() {
            return new Computer(this);
        }
    }
    @Override
    public String toString() {
        return "Computer{" +
                "CPU='" + cpu + '\'' +
                ", RAM=" + ram +
                ", storage=" + storage +
                '}';
    }
}
