/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proxypatternexample;

/**
 *
 * @author vigra
 */
public class RealImage implements Image {
    private String imageUrl;

    public RealImage(String imageUrl) {
        this.imageUrl = imageUrl;
        loadImageFromRemoteServer();
    }

    private void loadImageFromRemoteServer() {
        System.out.println("Loading image from remote server: " + imageUrl);
    }

    @Override
    public void display() {
        System.out.println("Displaying image: " + imageUrl);
    }
}
