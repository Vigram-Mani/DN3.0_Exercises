/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.factorydesignpatternexample;

/**
 *
 * @author vigra
 */
public class WordDocument implements Document{
    public void create(){
        System.out.println("Creating Word Document");
    }
    public void delete(){
        System.out.println("Deleting Word Document");
    }
}
