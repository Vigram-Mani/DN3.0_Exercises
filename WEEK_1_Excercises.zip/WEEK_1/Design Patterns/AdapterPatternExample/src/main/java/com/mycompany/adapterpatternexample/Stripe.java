/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.adapterpatternexample;

/**
 *
 * @author vigra
 */
public class Stripe {
    public void makePayment(double amount) {
        System.out.println("Processing Stripe payment of rupees " + amount);
    }
}
