/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mvcpatternexample;

/**
 *
 * @author vigra
 */
public class MVCPatternExample {

    public static void main(String[] args) {
        Student model = new Student("1", "Vigram", "O");StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);
        controller.updateView();
        controller.setStudentName("Vigram");
        controller.setStudentGrade("O");
        controller.updateView();
    }
}
