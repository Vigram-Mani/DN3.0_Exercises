package com.library.repository;

public class BookRepository {
    public  BookRepository(){
        System.out.println("Book repository class object is created using spring");
    }
    public  void success(){
        System.out.println("Vanthuruchu da mapla");
    }
}
