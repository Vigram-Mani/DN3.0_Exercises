/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.builderpatternexample;

/**
 *
 * @author vigra
 */
public class BuilderPatternExample {

    public static void main(String[] args) {
        Computer gamingPC = new Computer.Builder()
                .cpuSetter("Intel i9")
                .ramSetter(32)
                .storageSetter(1000)
                .build();

        Computer officePC = new Computer.Builder()
                .cpuSetter("Intel i5")
                .ramSetter(16)
                .storageSetter(500)
                .build();

        System.out.println("Gaming PC: " + gamingPC);
        System.out.println("Office PC: " + officePC);
    }
}
