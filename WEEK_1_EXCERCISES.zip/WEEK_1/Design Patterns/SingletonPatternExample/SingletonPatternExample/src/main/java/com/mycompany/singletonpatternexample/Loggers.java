/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.singletonpatternexample;

/**
 *
 * @author vigra
 */
public class Loggers {
    private static Loggers logger = null;
    
    private Loggers(){
        
    }
    public static Loggers getInstance(){
        if(logger == null){
            logger = new Loggers();
        }
        return logger;
    }
}

