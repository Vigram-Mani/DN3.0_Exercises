/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.singletonpatternexample;

/**
 *
 * @author vigra
 */
public class SingletonPatternExample {

    public static void main(String[] args) {
        Loggers obj = Loggers.getInstance();
        Loggers obj1 = Loggers.getInstance();
        
        if(obj == obj1){
            System.out.println("Objects have the same reference");
        }
        else{
            System.out.println("Objects have different reference");
        }
    }
}
