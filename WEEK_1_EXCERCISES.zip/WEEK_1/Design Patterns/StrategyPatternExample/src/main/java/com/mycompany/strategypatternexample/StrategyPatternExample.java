/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.strategypatternexample;

/**
 *
 * @author vigra
 */
public class StrategyPatternExample {

    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9101-1121", "John Doe", "123", "12/24");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.executePayment(200);
        System.out.println("");

        PaymentStrategy payPalPayment = new PayPalPayment("johndoe@example.com", "password");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.executePayment(100);
    }
}
