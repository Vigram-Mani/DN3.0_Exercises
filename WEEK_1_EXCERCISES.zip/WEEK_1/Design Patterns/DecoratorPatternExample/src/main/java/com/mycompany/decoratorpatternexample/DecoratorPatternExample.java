/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.decoratorpatternexample;

/**
 *
 * @author vigra
 */
public class DecoratorPatternExample {

    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier emailAndSMSNotifier = new SmsNotifierDecorator(emailNotifier);
        Notifier emailSMSAndSlackNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);

        String message = "This is a test notification.";

        System.out.println("Sending notification via Email:");
        emailNotifier.send(message);

        System.out.println("\nSending notification via Email and SMS:");
        emailAndSMSNotifier.send(message);

        System.out.println("\nSending notification via Email, SMS, and Slack:");
        emailSMSAndSlackNotifier.send(message);
    }
}
