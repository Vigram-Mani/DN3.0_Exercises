/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.adapterpatternexample;

/**
 *
 * @author vigra
 */
public class Paypal {
    public void sendPayment(double amount) {
        System.out.println("Processing PayPal payment of rupees " + amount);
    }
}
