/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.adapterpatternexample;

/**
 *
 * @author vigra
 */
public class AdapterPatternExample {

    public static void main(String[] args) {
        Payment paypal = new PaypalAdapter(new Paypal());
        paypal.processPayment(100);

        Payment stripe = new StripeAdapter(new Stripe());
        stripe.processPayment(200);

        Payment square = new SquareAdapter(new Square());
        square.processPayment(300);
    }
}
