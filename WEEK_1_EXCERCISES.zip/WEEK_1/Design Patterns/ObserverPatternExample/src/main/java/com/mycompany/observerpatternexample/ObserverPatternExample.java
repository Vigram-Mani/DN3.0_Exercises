/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.observerpatternexample;

/**
 *
 * @author vigra
 */
public class ObserverPatternExample {

    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp = new MobileApp("Mobile App");
        Observer webApp = new WebApp("Web App");

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        stockMarket.setStockPrice(100);
        System.out.println("");

        stockMarket.setStockPrice(200);
        System.out.println("");

        stockMarket.deregisterObserver(webApp);

        stockMarket.setStockPrice(300);
    }
}
