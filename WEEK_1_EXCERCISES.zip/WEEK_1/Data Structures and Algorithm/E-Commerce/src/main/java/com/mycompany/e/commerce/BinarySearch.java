/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;

import java.util.Arrays;

/**
 *
 * @author vigra
 */

public class BinarySearch {
    public static Product binarySearch(Product[] products, String searchTerm) {
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareToIgnoreCase(p2.getProductName()));
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int middle = (left + right) / 2;
            int comparison = products[middle].getProductName().compareToIgnoreCase(searchTerm);

            if (comparison == 0) {
                return products[middle];
            } else if (comparison < 0) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }
        return null; // If product is not found
    }
}
