/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.librarymanagementsystem;

/**
 *
 * @author vigra
 */
import java.util.*;
public class LibraryManagementSystem {

    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book("B001", "Java Programming", "Alice Smith"));
        books.add(new Book("B002", "Data Structures", "Bob Johnson"));
        books.add(new Book("B003", "Algorithms", "Charlie Brown"));
        Collections.sort(books, Comparator.comparing(Book::getTitle));
        LibraryManager manager = new LibraryManager();
        System.out.println("Linear Search:");
        Book book = manager.searchBookByTitleLinear(books, "Data Structures");
        System.out.println(book != null ? book : "Book not found.");
        System.out.println("\nBinary Search:");
        book = manager.searchBookByTitleBinary(books, "Data Structures");
        System.out.println(book != null ? book : "Book not found.");
    }
}
